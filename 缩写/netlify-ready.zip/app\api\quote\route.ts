import { NextResponse } from "next/server";
import { generateQuoteExcel } from "../../../lib/quote-service";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const priceFile = formData.get("priceFile");
    const templateFile = formData.get("templateFile");
    const customerName = String(formData.get("customerName") || "");
    const remark = String(formData.get("remark") || "");
    const products = String(formData.get("products") || "");

    if (!(priceFile instanceof File) || !(templateFile instanceof File)) {
      return NextResponse.json({ error: "请上传销售价格表和报价模板。" }, { status: 400 });
    }

    const priceBuffer = Buffer.from(await priceFile.arrayBuffer());
    const templateBuffer = Buffer.from(await templateFile.arrayBuffer());

    const result = await generateQuoteExcel({
      priceBuffer,
      templateBuffer,
      customerName,
      remark,
      productInput: products
    });

    const stamp = timestamp();
    return NextResponse.json({
      fileName: `报价单_${stamp}.xlsx`,
      fileBase64: result.buffer.toString("base64"),
      matched: result.matched.map((item) => ({
        input: item.request.input,
        quantity: item.request.quantity,
        abbreviation: item.product.abbreviation,
        productName: item.product.productName,
        specification: item.product.specification,
        price: item.product.price,
        sheetName: item.product.sheetName,
        matchType: item.matchType
      })),
      unmatched: result.unmatched
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "报价单生成失败。" },
      { status: 500 }
    );
  }
}

function timestamp() {
  const date = new Date();
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  const hh = String(date.getHours()).padStart(2, "0");
  const mi = String(date.getMinutes()).padStart(2, "0");
  return `${yyyy}${mm}${dd}_${hh}${mi}`;
}
