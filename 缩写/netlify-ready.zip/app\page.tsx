"use client";

import { useState } from "react";

type ApiResult = {
  fileName: string;
  fileBase64: string;
  matched: Array<{
    input: string;
    quantity: number;
    abbreviation: string;
    productName: string;
    specification: string;
    price: string | number;
    sheetName: string;
    matchType: string;
  }>;
  unmatched: Array<{ input: string; quantity: number }>;
};

export default function HomePage() {
  const [priceFile, setPriceFile] = useState<File | null>(null);
  const [templateFile, setTemplateFile] = useState<File | null>(null);
  const [customerName, setCustomerName] = useState("");
  const [remark, setRemark] = useState("");
  const [products, setProducts] = useState("MS40*2\nWA10*1\nRT10*3");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ApiResult | null>(null);
  const [error, setError] = useState("");

  async function submit() {
    setError("");
    setResult(null);

    if (!priceFile || !templateFile) {
      setError("请同时上传销售价格表和报价模板。");
      return;
    }

    const formData = new FormData();
    formData.append("priceFile", priceFile);
    formData.append("templateFile", templateFile);
    formData.append("customerName", customerName);
    formData.append("remark", remark);
    formData.append("products", products);

    setLoading(true);
    try {
      const response = await fetch("/api/quote", {
        method: "POST",
        body: formData
      });
      const payload = await response.json();

      if (!response.ok) {
        throw new Error(payload.error || "生成失败。");
      }

      setResult(payload);
      downloadExcel(payload);
    } catch (err) {
      setError(err instanceof Error ? err.message : "生成失败。");
    } finally {
      setLoading(false);
    }
  }

  function downloadExcel(payload: ApiResult) {
    const byteCharacters = atob(payload.fileBase64);
    const bytes = new Uint8Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i += 1) {
      bytes[i] = byteCharacters.charCodeAt(i);
    }
    const blob = new Blob([bytes], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = payload.fileName;
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="min-h-screen bg-[linear-gradient(135deg,#eef3f8_0%,#f8fbfd_55%,#e8f6f3_100%)] p-4 md:p-8">
      <section className="mx-auto max-w-6xl">
        <header className="mb-6 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="mb-2 text-sm font-bold text-brand">Excel报价系统</p>
            <h1 className="text-3xl font-black tracking-normal md:text-5xl">自动Excel报价单生成系统</h1>
          </div>
          <div className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-muted shadow-sm">
            基于模板填值
          </div>
        </header>

        <div className="grid gap-4 lg:grid-cols-[0.95fr_1.05fr]">
          <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="mb-4 text-xl font-black">上传Excel</h2>
            <div className="grid gap-4">
              <FileBox
                title="销售价格表"
                hint="支持 .xls / .xlsx，系统会读取所有Sheet建立产品数据库。"
                file={priceFile}
                accept=".xls,.xlsx"
                onChange={setPriceFile}
              />
              <FileBox
                title="报价模板"
                hint="必须是 .xlsx，系统会基于原模板直接填值并保留公式。"
                file={templateFile}
                accept=".xlsx,.xlsm"
                onChange={setTemplateFile}
              />
              <label className="grid gap-2">
                <span className="text-sm font-bold text-slate-700">客户名称</span>
                <input
                  className="h-11 rounded-lg border border-slate-200 bg-slate-50 px-3 outline-none focus:border-brand focus:ring-4 focus:ring-teal-100"
                  value={customerName}
                  onChange={(event) => setCustomerName(event.target.value)}
                  placeholder="例如：ABC Lighting"
                />
              </label>
              <label className="grid gap-2">
                <span className="text-sm font-bold text-slate-700">备注</span>
                <textarea
                  className="min-h-24 resize-y rounded-lg border border-slate-200 bg-slate-50 p-3 outline-none focus:border-brand focus:ring-4 focus:ring-teal-100"
                  value={remark}
                  onChange={(event) => setRemark(event.target.value)}
                  placeholder="报价说明、交期、付款方式等"
                />
              </label>
            </div>
          </section>

          <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="mb-4 text-xl font-black">输入报价产品</h2>
            <textarea
              className="min-h-[310px] w-full resize-y rounded-lg border border-slate-200 bg-slate-50 p-4 leading-7 outline-none focus:border-brand focus:ring-4 focus:ring-teal-100"
              value={products}
              onChange={(event) => setProducts(event.target.value)}
              placeholder={"每行一个产品，例如：\nMS40*2\nLight Panel 60*1\n10寸*3"}
            />
            <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm text-muted">支持缩写、全称、规格，忽略大小写和空格。</p>
              <button
                className="h-11 rounded-lg bg-brand px-6 font-black text-white hover:bg-teal-800 disabled:cursor-not-allowed disabled:bg-slate-400"
                disabled={loading}
                onClick={submit}
              >
                {loading ? "生成中..." : "生成并下载Excel"}
              </button>
            </div>
            {error ? <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm font-bold text-red-700">{error}</p> : null}
          </section>
        </div>

        {result ? (
          <section className="mt-4 grid gap-4 rounded-lg border border-slate-200 bg-white p-5 shadow-sm md:grid-cols-2">
            <ResultList
              title={`已匹配 ${result.matched.length} 个`}
              items={result.matched.map((item) => `${item.input} x ${item.quantity} -> ${item.abbreviation || item.productName}`)}
              empty="没有匹配到产品"
            />
            <ResultList
              title={`未匹配 ${result.unmatched.length} 个`}
              items={result.unmatched.map((item) => `${item.input} x ${item.quantity}`)}
              empty="无"
            />
          </section>
        ) : null}
      </section>
    </main>
  );
}

function FileBox({
  title,
  hint,
  file,
  accept,
  onChange
}: {
  title: string;
  hint: string;
  file: File | null;
  accept: string;
  onChange: (file: File | null) => void;
}) {
  return (
    <label className="grid cursor-pointer gap-2 rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4 hover:border-brand hover:bg-teal-50">
      <span className="text-sm font-black text-slate-800">{title}</span>
      <span className="text-sm text-muted">{file ? file.name : hint}</span>
      <input
        className="hidden"
        type="file"
        accept={accept}
        onChange={(event) => onChange(event.target.files?.[0] || null)}
      />
    </label>
  );
}

function ResultList({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <div>
      <h3 className="mb-3 font-black">{title}</h3>
      <ul className="grid gap-2">
        {(items.length ? items : [empty]).map((item) => (
          <li key={item} className="rounded-lg bg-slate-50 px-3 py-2 text-sm text-slate-700">
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
