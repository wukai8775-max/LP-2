# 自动Excel报价单生成系统

这是一个基于 Next.js 的 Excel 报价单生成网站。

用户上传：

1. 销售价格表 Excel，支持 `.xls` / `.xlsx`
2. 报价模板 Excel，建议使用 `.xlsx`

然后输入客户名称、备注和产品列表，系统会自动匹配产品并基于原报价模板生成最终 `.xlsx` 报价单。

## 功能

- 读取销售价格表的所有 Sheet。
- 建立产品数据库，字段包括缩写、产品全称、规格、单价、采购价、来源 Sheet。
- 支持 `MS40*2`、`WA10*1` 这类产品数量输入。
- 优先按产品缩写匹配。
- 支持产品全称模糊匹配。
- 支持规格匹配，例如 `10寸` 匹配 `10 inch`。
- 忽略大小写和空格，例如 `MS 40` 等同于 `MS40`。
- 基于原 Excel 报价模板直接填值。
- 不覆盖模板中已有公式。
- 导出标准 `.xlsx`。
- 未匹配产品会继续生成，并在 Excel 末尾列出。

## Excel 处理策略

销售价格表读取使用 `xlsx`，原因是价格表可能是旧版 `.xls`，而 ExcelJS 不支持稳定读取 `.xls`。

报价模板读取和导出使用 `exceljs`：

```ts
const workbook = new ExcelJS.Workbook();
await workbook.xlsx.load(templateBuffer);
```

系统只填写：

- 产品缩写
- 产品名称
- 产品规格
- 数量
- 单价
- 客户名称
- 备注

如果目标单元格已经是公式，系统不会覆盖该单元格。

## 项目目录

```txt
.
├─ app/
│  ├─ api/
│  │  └─ quote/
│  │     └─ route.ts
│  ├─ globals.css
│  ├─ layout.tsx
│  └─ page.tsx
├─ lib/
│  ├─ input.ts
│  ├─ match.ts
│  ├─ price-workbook.ts
│  ├─ quote-service.ts
│  ├─ quote-template.ts
│  └─ types.ts
├─ samples/
│  ├─ sales-price.xls
│  └─ quote-template.xlsx
├─ package.json
├─ tailwind.config.ts
├─ postcss.config.js
├─ next.config.mjs
├─ netlify.toml
└─ README.md
```

## 本地运行

```bash
npm install
npm run dev
```

打开：

```txt
http://localhost:3000
```

测试文件在 `samples/` 目录中：

- `samples/sales-price.xls`
- `samples/quote-template.xlsx`

## Netlify 部署

Netlify 需要安装依赖并执行 Next.js 构建。

构建配置已经写在 `netlify.toml`：

```toml
[build]
  command = "npm run build"
  publish = ".next"

[[plugins]]
  package = "@netlify/plugin-nextjs"
```

部署步骤：

1. 把项目推送到 GitHub / GitLab。
2. 在 Netlify 中选择 `Add new site`。
3. 选择该仓库。
4. Netlify 自动执行 `npm install` 和 `npm run build`。
5. 部署完成后即可在线使用。

## 模板识别规则

系统会优先在报价模板中自动寻找表头：

- 产品名称：`Product Name`、`产品名称`、`产品全称`、`品名`
- 缩写：`Abbreviation`、`产品缩写`、`缩写`
- 规格：`Specification`、`产品规格`、`规格`
- 数量：`QTY`、`Quantity`、`数量`
- 单价：`Price`、`Unit Price`、`单价`
- 备注：`Remark`、`备注`

如果没有识别到表头，会使用默认填充位置：

- 第 12 行开始填产品
- B 列：产品名称
- C 列：规格
- F 列：数量
- G 列：单价

这个默认值对应常见的 `=F12*G12` 总价公式结构。

## 注意事项

- 报价模板必须尽量使用 `.xlsx`，这是 ExcelJS 的稳定读写格式。
- 旧版 `.xls` 可作为销售价格表上传，但不建议作为报价模板。
- Excel 公式会保留，并设置为打开文件后重新计算。
- 如果模板中的产品区行数不够，超出部分会列入未匹配/未写入清单，避免覆盖合计、运费、手续费等公式区域。
