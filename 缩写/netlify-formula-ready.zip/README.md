# 按原Excel公式生成报价单

这是一个 Next.js 报价单生成系统。

当前版本以你最新提供的 `5.21销售价格表 (11) (2).xls` 为准：

- 用户只上传这一份含公式的销售价格表。
- 输入客户名称、备注和产品列表。
- 系统读取所有 Sheet 中的产品缩写、产品全称、规格、单价和公式结构。
- 系统匹配用户输入的产品。
- 系统隐藏未选中的产品行，尽量保留原工作簿公式结构。
- 最终导出标准 `.xlsx` 文件。

## 产品输入格式

支持：

```txt
MS40*2
WA10*1
RT10*3
```

也支持：

- 产品缩写匹配，优先级最高
- 产品全称模糊匹配
- 产品规格匹配
- 忽略大小写
- 忽略空格
- `10寸` 自动按 `10 inch` 参与匹配

## Excel 处理说明

因为你提供的是旧版 `.xls` 文件，系统使用 `xlsx` 读取工作簿和公式，然后导出为 `.xlsx`。

生成逻辑不是重画报价表，而是：

1. 读取原 Excel 工作簿。
2. 建立产品数据库。
3. 匹配用户输入产品。
4. 对未选中的产品行设置隐藏。
5. 按用户输入写入匹配产品行的 QTY。
6. 在末尾写入客户名称、备注和未匹配产品。
7. 导出 `.xlsx`。

## 项目目录

```txt
.
├─ app/
│  ├─ api/quote/route.ts
│  ├─ globals.css
│  ├─ layout.tsx
│  └─ page.tsx
├─ lib/
│  ├─ formula-workbook.ts
│  ├─ input.ts
│  ├─ match.ts
│  ├─ price-workbook.ts
│  └─ types.ts
├─ samples/
│  └─ formula-price-workbook.xls
├─ package.json
├─ netlify.toml
└─ README.md
```

## 本地运行

```bash
npm install
npm run dev
```

打开：

```txt
http://localhost:3000
```

测试文件：

```txt
samples/formula-price-workbook.xls
```

## Netlify 部署

该项目有 Next.js API 接口，不能只上传单个 HTML 文件。

部署建议：

1. 把整个项目上传到 GitHub。
2. 在 Netlify 中选择该仓库。
3. Netlify 会按 `netlify.toml` 执行：

```bash
npm run build
```

构建配置：

```toml
[build]
  command = "npm run build"
  publish = ".next"

[[plugins]]
  package = "@netlify/plugin-nextjs"
```

## 注意

`.xls` 是旧版 Excel 格式。系统会导出 `.xlsx`，公式会尽量保留并让 Excel 打开后重新计算。对于特别复杂的旧版 `.xls` 样式、图片、打印设置，建议先在 Excel 中另存为 `.xlsx` 再使用，可以获得更稳定的格式保留效果。
