import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "自动Excel报价单生成系统",
  description: "上传销售价格表和报价模板，自动生成保留格式与公式的Excel报价单"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
