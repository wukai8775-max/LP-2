import * as XLSX from "xlsx";
import type { ProductRecord } from "./types";
import { normalizeText } from "./match";

type ColumnMap = {
  abbreviation: number;
  productName: number;
  specification: number;
  price: number;
  discount?: number;
  purchasePrice?: number;
};

const headerAliases: Record<keyof ColumnMap, string[]> = {
  abbreviation: ["abbreviation", "abbreviatio", "abb eviatio", "abb", "产品缩写", "缩写", "简称"],
  productName: ["product name", "product", "产品全称", "产品名称", "品名", "名称"],
  specification: ["specification", "specificatio", "spec", "产品规格", "规格"],
  price: ["price ($/box)", "price", "unit price", "单价", "价格"],
  discount: ["discount", "折扣"],
  purchasePrice: ["采购单价", "purchase price", "cost"]
};

export function readPriceWorkbook(buffer: Buffer): ProductRecord[] {
  const workbook = XLSX.read(buffer, {
    type: "buffer",
    cellDates: true,
    cellFormula: true,
    cellNF: true
  });

  const records: ProductRecord[] = [];

  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet?.["!ref"]) continue;

    const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, raw: false, defval: "" });
    const headerInfo = findHeader(rows);
    if (!headerInfo) continue;

    for (let index = headerInfo.rowIndex + 1; index < rows.length; index += 1) {
      const row = rows[index] || [];
      const abbreviation = cell(row, headerInfo.columns.abbreviation);
      const productName = cell(row, headerInfo.columns.productName);
      const specification = cell(row, headerInfo.columns.specification);
      const price = cell(row, headerInfo.columns.price);

      if (!abbreviation && !productName && !specification) continue;

      records.push({
        abbreviation,
        productName,
        specification,
        price,
        discount: optionalCell(row, headerInfo.columns.discount),
        purchasePrice: optionalCell(row, headerInfo.columns.purchasePrice),
        sheetName,
        rowNumber: index + 1
      });
    }
  }

  return records;
}

function findHeader(rows: unknown[][]): { rowIndex: number; columns: ColumnMap } | null {
  const scanLimit = Math.min(rows.length, 60);

  for (let rowIndex = 0; rowIndex < scanLimit; rowIndex += 1) {
    const row = rows[rowIndex] || [];
    const columns = findColumns(row);
    if (columns.abbreviation >= 0 && columns.productName >= 0 && columns.price >= 0) {
      if (columns.specification < 0) columns.specification = columns.productName;
      return { rowIndex, columns };
    }
  }

  return null;
}

function findColumns(row: unknown[]): ColumnMap {
  return {
    abbreviation: findColumn(row, headerAliases.abbreviation),
    productName: findColumn(row, headerAliases.productName),
    specification: findColumn(row, headerAliases.specification),
    price: findColumn(row, headerAliases.price),
    discount: findColumn(row, headerAliases.discount),
    purchasePrice: findColumn(row, headerAliases.purchasePrice)
  };
}

function findColumn(row: unknown[], aliases: string[]) {
  return row.findIndex((value) => {
    const text = normalizeText(value);
    return aliases.some((alias) => text === normalizeText(alias) || text.includes(normalizeText(alias)));
  });
}

function cell(row: unknown[], index: number) {
  if (index < 0) return "";
  return String(row[index] ?? "").trim();
}

function optionalCell(row: unknown[], index?: number) {
  if (index == null || index < 0) return "";
  return cell(row, index);
}
