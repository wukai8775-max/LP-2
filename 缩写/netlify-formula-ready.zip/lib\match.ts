import type { MatchedProduct, ProductRecord, RequestedProduct } from "./types";

export function normalizeText(value: unknown): string {
  return String(value ?? "")
    .replace(/\u3000/g, " ")
    .replace(/(\d+)\s*(寸|吋)/gi, "$1 inch")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

export function compactText(value: unknown): string {
  return normalizeText(value).replace(/[\s._\-\/\\]+/g, "");
}

export function matchProducts(requested: RequestedProduct[], records: ProductRecord[]) {
  const matched: MatchedProduct[] = [];
  const unmatched: RequestedProduct[] = [];

  const abbreviationMap = new Map<string, ProductRecord>();
  const nameMap = new Map<string, ProductRecord>();

  for (const record of records) {
    const abbreviation = compactText(record.abbreviation);
    const name = compactText(record.productName);
    if (abbreviation && !abbreviationMap.has(abbreviation)) abbreviationMap.set(abbreviation, record);
    if (name && !nameMap.has(name)) nameMap.set(name, record);
  }

  for (const request of requested) {
    const query = compactText(request.input);
    const directAbbreviation = abbreviationMap.get(query);
    if (directAbbreviation) {
      matched.push({ request, product: directAbbreviation, matchType: "abbreviation", score: 100 });
      continue;
    }

    const directName = nameMap.get(query);
    if (directName) {
      matched.push({ request, product: directName, matchType: "productName", score: 95 });
      continue;
    }

    const fuzzy = findBestFuzzyMatch(request.input, records);
    if (fuzzy) {
      matched.push({ request, ...fuzzy });
    } else {
      unmatched.push(request);
    }
  }

  return { matched, unmatched };
}

function findBestFuzzyMatch(input: string, records: ProductRecord[]) {
  let best: { product: ProductRecord; matchType: string; score: number } | null = null;

  for (const record of records) {
    const nameScore = scoreCandidate(input, record.productName, "productNameFuzzy");
    const specScore = scoreCandidate(input, record.specification, "specification");
    const abbreviationScore = scoreCandidate(input, record.abbreviation, "abbreviationFuzzy");
    const candidate = [nameScore, specScore, abbreviationScore].sort((a, b) => b.score - a.score)[0];

    if (candidate.score >= 55 && (!best || candidate.score > best.score)) {
      best = { product: record, matchType: candidate.type, score: candidate.score };
    }
  }

  return best;
}

function scoreCandidate(input: string, candidate: unknown, type: string) {
  const queryCompact = compactText(input);
  const candidateCompact = compactText(candidate);
  const query = normalizeText(input);
  const candidateText = normalizeText(candidate);

  if (!queryCompact || !candidateCompact) return { type, score: 0 };
  if (candidateCompact === queryCompact) return { type, score: 90 };
  if (candidateCompact.includes(queryCompact)) return { type, score: 76 };
  if (queryCompact.includes(candidateCompact) && candidateCompact.length >= 3) return { type, score: 70 };

  const queryTokens = query.split(/\s+/g).filter(Boolean);
  const candidateTokens = candidateText.split(/\s+/g).filter(Boolean);
  if (queryTokens.length > 0) {
    const hitCount = queryTokens.filter((token) => candidateTokens.some((candidateToken) => candidateToken.includes(token))).length;
    const coverage = hitCount / queryTokens.length;
    if (coverage === 1) return { type, score: 68 };
    if (coverage >= 0.66) return { type, score: 58 };
  }

  return { type, score: 0 };
}
