import * as XLSX from "xlsx";
import { matchProducts } from "./match";
import { parseProductInput } from "./input";
import { readPriceWorkbook } from "./price-workbook";
import type { ProductRecord, RequestedProduct } from "./types";

export async function generateFromFormulaWorkbook({
  workbookBuffer,
  customerName,
  remark,
  productInput
}: {
  workbookBuffer: Buffer;
  customerName: string;
  remark: string;
  productInput: string;
}) {
  const records = readPriceWorkbook(workbookBuffer);
  if (records.length === 0) {
    throw new Error("Excel中没有识别到产品数据，请检查表头是否包含 Abbreviation / Product Name / Price。");
  }

  const requested = parseProductInput(productInput);
  if (requested.length === 0) {
    throw new Error("请输入需要报价的产品。");
  }

  const { matched, unmatched } = matchProducts(requested, records);
  const workbook = XLSX.read(workbookBuffer, {
    type: "buffer",
    cellDates: true,
    cellFormula: true,
    cellNF: true,
    cellStyles: true,
    bookVBA: true
  });

  const matchedKeys = new Set(matched.map((item) => recordKey(item.product)));
  hideUnselectedProductRows(workbook, records, matchedKeys);
  writeRequestedQuantities(workbook, matched);
  appendInfo(workbook, {
    customerName,
    remark,
    unmatched
  });

  const buffer = XLSX.write(workbook, {
    type: "buffer",
    bookType: "xlsx",
    cellStyles: true,
    compression: true
  });

  return {
    buffer: Buffer.from(buffer),
    matched,
    unmatched
  };
}

function hideUnselectedProductRows(workbook: XLSX.WorkBook, records: ProductRecord[], matchedKeys: Set<string>) {
  for (const record of records) {
    const sheet = workbook.Sheets[record.sheetName];
    if (!sheet) continue;
    if (!sheet["!rows"]) sheet["!rows"] = [];

    const rowIndex = record.rowNumber - 1;
    if (!sheet["!rows"][rowIndex]) sheet["!rows"][rowIndex] = {};
    sheet["!rows"][rowIndex].hidden = !matchedKeys.has(recordKey(record));
  }
}

function writeRequestedQuantities(
  workbook: XLSX.WorkBook,
  matchedProducts: Array<{ product: ProductRecord; request: RequestedProduct }>
) {
  const quantityByRecord = new Map<string, number>();
  matchedProducts.forEach((item) => {
    quantityByRecord.set(recordKey(item.product), item.request.quantity || 1);
  });

  for (const { product: record } of matchedProducts) {
    const sheet = workbook.Sheets[record.sheetName];
    if (!sheet?.["!ref"]) continue;
    const qtyColumn = findHeaderColumn(sheet, record.rowNumber, ["qty", "quantity", "数量"]);
    if (qtyColumn < 0) continue;

    const address = XLSX.utils.encode_cell({ r: record.rowNumber - 1, c: qtyColumn });
    const existing = sheet[address] || { t: "n" };
    sheet[address] = {
      ...existing,
      t: "n",
      v: quantityByRecord.get(recordKey(record)) || 1
    };
  }
}

function findHeaderColumn(sheet: XLSX.WorkSheet, productRowNumber: number, aliases: string[]) {
  const range = XLSX.utils.decode_range(sheet["!ref"] || "A1:A1");
  const headerRow = Math.max(range.s.r, productRowNumber - 2);

  for (let col = range.s.c; col <= range.e.c; col += 1) {
    const cell = sheet[XLSX.utils.encode_cell({ r: headerRow, c: col })];
    const text = String(cell?.w ?? cell?.v ?? "").replace(/\s+/g, " ").trim().toLowerCase();
    if (aliases.some((alias) => text === alias || text.includes(alias))) return col;
  }

  return -1;
}

function appendInfo(
  workbook: XLSX.WorkBook,
  {
    customerName,
    remark,
    unmatched
  }: {
    customerName: string;
    remark: string;
    unmatched: RequestedProduct[];
  }
) {
  const firstSheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[firstSheetName];
  if (!sheet) return;

  const range = XLSX.utils.decode_range(sheet["!ref"] || "A1:A1");
  let row = range.e.r + 2;
  const col = range.s.c;

  if (customerName) {
    sheet[XLSX.utils.encode_cell({ r: row, c: col })] = { t: "s", v: "客户名称：" };
    sheet[XLSX.utils.encode_cell({ r: row, c: col + 1 })] = { t: "s", v: customerName };
    row += 1;
  }

  if (remark) {
    sheet[XLSX.utils.encode_cell({ r: row, c: col })] = { t: "s", v: "备注：" };
    sheet[XLSX.utils.encode_cell({ r: row, c: col + 1 })] = { t: "s", v: remark };
    row += 1;
  }

  if (unmatched.length > 0) {
    row += 1;
    sheet[XLSX.utils.encode_cell({ r: row, c: col })] = { t: "s", v: "未匹配产品：" };
    unmatched.forEach((item, index) => {
      sheet[XLSX.utils.encode_cell({ r: row + index + 1, c: col })] = { t: "s", v: `${index + 1}. ${item.input}` };
      sheet[XLSX.utils.encode_cell({ r: row + index + 1, c: col + 1 })] = { t: "n", v: item.quantity };
    });
    row += unmatched.length + 1;
  }

  sheet["!ref"] = XLSX.utils.encode_range({
    s: range.s,
    e: { r: Math.max(range.e.r, row), c: range.e.c }
  });
}

function recordKey(record: ProductRecord) {
  return `${record.sheetName}::${record.rowNumber}::${record.abbreviation}`;
}
